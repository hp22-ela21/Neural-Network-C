/**************************************************************************************************
* def.h: Inneh�llande inkluderingsdirektiv och definitioner samt anv�nds i hela programmet.
**************************************************************************************************/
#ifndef DEF_H_
#define DEF_H_

/* Inkluderingsdirektiv: */
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <stdbool.h>

#endif /* DEF_H_ */